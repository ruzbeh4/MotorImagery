# MotorImagery
Exploring and comparing different ML approaches to classify Motor Imagery Data
